#Beerious
###An app for those who feel serious about beer
--
Telerik NativeScript Course project by Team 11:

* [SDobrev](https://github.com/SDobrev)
* [alara_kalama](https://github.com/alaraKalama)

--
###The App

![alt text](icon copy.png)

Beerious is for those who want to taste every possible beer there is. 

You can browse our beer database and create wishlists with the beers around the world you want to try, add all the beers you already tried and see where your beer experience stands among your friends. 
You can add pictures of course and check in the location you found the desired cold beer. Cheers!

--

###Device APIs
* Camera
* Geolocation



###External npm modules 
* email-validator
* 


###Data

* Telerik Backend Services
* SQLite we hope